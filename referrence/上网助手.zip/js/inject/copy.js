﻿document.body.oncontextmenu=null;
document.body.ondragstart=null;
document.body.onselectstart =null;
document.body.onselect=null;
document.body.oncopy=null;
document.body.onbeforecopy=null;
document.body.onmouseup=null;
document.body.onmousedown=null;