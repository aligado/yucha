﻿if(self!=parent) {
	window.open(location.href);
}